'use client';
import Link from 'next/link';
import {DropdownMenu} from 'radix-ui';
import {useRef} from 'react';
import './language-menu.css';
const languages=[['en','English'],['zh-Hans','简体中文'],['zh-Hant','繁體中文'],['ja','日本語'],['ko','한국어'],['es','Español']] as const;
export default function LanguageMenu({locale,ariaLabel}:{locale:string;ariaLabel:string}){
 const pointerSelection=useRef(false);
 return <DropdownMenu.Root modal={false} onOpenChange={open=>{if(open)pointerSelection.current=false}}>
  <DropdownMenu.Trigger className="brand-language-trigger" aria-label={`${ariaLabel}: ${languages.find(([id])=>id===locale)?.[1]??locale}`}>
   <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c5 5 5 13 0 18-5-5-5-13 0-18"/></svg>
   <span>{languages.find(([id])=>id===locale)?.[1]??locale}</span>
   <svg className="brand-language-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="m7 10 5 5 5-5"/></svg>
  </DropdownMenu.Trigger>
  <DropdownMenu.Portal><DropdownMenu.Content className="brand-language-menu" align="end" sideOffset={8} collisionPadding={16} loop aria-label={ariaLabel}
   onPointerDownCapture={()=>{pointerSelection.current=true}}
   onKeyDownCapture={()=>{pointerSelection.current=false}}
   onCloseAutoFocus={event=>{
    // Pointer selection must not flash a keyboard focus ring before navigation.
    // Keyboard selection and Escape still restore focus through Radix.
    if(pointerSelection.current)event.preventDefault();
   }}
  >{languages.map(([id,name])=><DropdownMenu.Item key={id} asChild><Link className="brand-language-item" href={`/${id}/`} replace scroll={false} lang={id} hrefLang={id} aria-current={id===locale?'page':undefined} onClick={event=>{if(id===locale&&!event.metaKey&&!event.ctrlKey&&!event.shiftKey&&!event.altKey)event.preventDefault()}}><span>{name}</span>{id===locale&&<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>}</Link></DropdownMenu.Item>)}</DropdownMenu.Content></DropdownMenu.Portal>
 </DropdownMenu.Root>;
}
