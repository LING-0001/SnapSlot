'use client';
import {useCallback,useEffect,useRef,useState} from 'react';
import {AlertDialog} from 'radix-ui';
import './confirm-dialog.css';

type Options={confirmLabel?:string;destructive?:boolean};
type Request={message:string;options:Options;resolve:(value:boolean)=>void;initiator:HTMLElement|null};
export default function useConfirmation(copy:{confirmLabel:string;cancelLabel:string}){
 const [request,setRequest]=useState<Request|null>(null);
 const current=useRef<Request|null>(null);
 const ask=useCallback((message:string,options:Options={})=>{
  if(current.current)return Promise.resolve(false);
  return new Promise<boolean>(resolve=>{const next={message,options,resolve,initiator:document.activeElement instanceof HTMLElement?document.activeElement:null};current.current=next;setRequest(next)});
 },[]);
 const finish=useCallback((value:boolean)=>{const previous=current.current;current.current=null;setRequest(null);previous?.resolve(value)},[]);
 useEffect(()=>()=>{current.current?.resolve(false);current.current=null},[]);
 return {ask,open:!!request,confirmation:request?<AlertDialog.Root open onOpenChange={open=>{if(!open)finish(false)}}>
  <AlertDialog.Portal><AlertDialog.Overlay className="brand-confirm-overlay"/>
   <AlertDialog.Content className="brand-confirm-panel" aria-describedby={undefined} onCloseAutoFocus={event=>{event.preventDefault();const previous=request.initiator;if(previous?.isConnected&&!previous.closest('[inert]')&&!previous.matches(':disabled'))previous.focus({preventScroll:true})}}>
    <AlertDialog.Title asChild><h2>{request.message}</h2></AlertDialog.Title>
    <div className="brand-confirm-actions"><AlertDialog.Cancel asChild><button type="button" onClick={()=>finish(false)}>{copy.cancelLabel}</button></AlertDialog.Cancel><AlertDialog.Action asChild><button type="button" className={request.options.destructive?'is-destructive':'is-primary'} onClick={()=>finish(true)}>{request.options.confirmLabel||copy.confirmLabel}</button></AlertDialog.Action></div>
   </AlertDialog.Content>
  </AlertDialog.Portal>
 </AlertDialog.Root>:null};
}
