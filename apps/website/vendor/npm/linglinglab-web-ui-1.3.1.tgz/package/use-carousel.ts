'use client';
import {useCallback,useEffect,useRef,useState,type KeyboardEvent,type FocusEvent,type DragEvent} from 'react';
import useEmblaCarousel from 'embla-carousel-react';

/** Embla movement plus a cancellable idle timer, shared without product data. */
export default function useCarousel({count,intervalMs}:{count:number;intervalMs:number}){
 const [emblaRef,api]=useEmblaCarousel({loop:true,align:'start',duration:25,dragThreshold:8,watchFocus:false});
 const nodeRef=useRef<HTMLElement|null>(null);
 const container=useRef<HTMLElement|null>(null);
 const containerRef=useCallback((node:HTMLElement|null)=>{container.current=node},[]);
 const timer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
 const ref=useCallback((node:HTMLElement|null)=>{nodeRef.current=node;emblaRef(node)},[emblaRef]);
 const [active,setActive]=useState(0),[dragging,setDragging]=useState(false),[moving,setMoving]=useState(false),[focused,setFocused]=useState(false),[visible,setVisible]=useState(true),[reduced,setReduced]=useState(false),[restartKey,setRestartKey]=useState(0);
 const reducedRef=useRef(reduced);reducedRef.current=reduced;
 const wheel=useRef({delta:0,last:0,locked:false,direction:0,reverse:0,peak:0,previous:0,tail:false});
 const cancel=useCallback(()=>{if(timer.current!==undefined){clearTimeout(timer.current);timer.current=undefined}},[]);
 const restart=useCallback(()=>{cancel();setRestartKey(value=>value+1)},[cancel]);
 const move=useCallback((by:number)=>{cancel();if(by<0)api?.scrollPrev(reduced);else api?.scrollNext(reduced);setRestartKey(value=>value+1)},[api,reduced,cancel]);
 const goTo=useCallback((index:number)=>{cancel();api?.scrollTo(index,reduced);setRestartKey(value=>value+1)},[api,reduced,cancel]);
 useEffect(()=>{
  if(!api)return;
  const initialize=()=>{cancel();setActive(api.selectedScrollSnap());setMoving(false);setRestartKey(value=>value+1)};
  const select=()=>{cancel();setActive(api.selectedScrollSnap());setMoving(!reducedRef.current)};
  const down=()=>{cancel();setDragging(true)};
  const up=()=>{cancel();setDragging(false);setRestartKey(value=>value+1)};
  const settle=()=>{cancel();setMoving(false);setRestartKey(value=>value+1)};
  initialize();api.on('select',select).on('reInit',initialize).on('pointerDown',down).on('pointerUp',up).on('settle',settle);
  return()=>{cancel();api.off('select',select).off('reInit',initialize).off('pointerDown',down).off('pointerUp',up).off('settle',settle)};
 },[api,cancel]);
 useEffect(()=>{
  const motion=matchMedia('(prefers-reduced-motion: reduce)');
  const update=()=>{cancel();setVisible(!document.hidden);setReduced(motion.matches)};update();
  document.addEventListener('visibilitychange',update);motion.addEventListener('change',update);
  return()=>{cancel();document.removeEventListener('visibilitychange',update);motion.removeEventListener('change',update)};
 },[cancel]);
 useEffect(()=>{
  cancel();
  if(!api||count<2||intervalMs<=0||focused||dragging||moving||!visible||reduced)return;
  timer.current=setTimeout(()=>{timer.current=undefined;api.scrollNext()},intervalMs);
  return cancel;
 },[api,active,count,intervalMs,focused,dragging,moving,visible,reduced,restartKey,cancel]);
 useEffect(()=>{
  const node=container.current??nodeRef.current;if(!node||!api)return;
  const onWheel=(event:WheelEvent)=>{
   // Capture horizontal input over controls as well as slides. Even tiny horizontal
   // events must be cancelled before the browser claims a history-navigation gesture.
   if(!event.deltaX||Math.abs(event.deltaX)<Math.abs(event.deltaY))return;
   if(event.cancelable)event.preventDefault();
   const now=performance.now(),state=wheel.current;
   const delta=event.deltaX*(event.deltaMode===1?16:event.deltaMode===2?node.clientWidth:1),magnitude=Math.abs(delta),direction=Math.sign(delta);
   const fresh=now-state.last>140;
   // A fresh impulse after a decaying tail can be another stroke without a long gap.
   const impulse=state.tail&&magnitude>=18&&magnitude>state.previous*2;
   if(fresh||impulse){state.delta=0;state.locked=false;state.reverse=0;state.peak=0;state.tail=false}
   state.last=now;cancel();setRestartKey(value=>value+1);
   state.peak=Math.max(state.peak,magnitude);
   if(magnitude<state.peak*.2)state.tail=true;
   state.previous=magnitude;
   if(state.locked){
    // A deliberate reversal is a new gesture; same-direction momentum stays locked.
    state.reverse=direction!==state.direction?state.reverse+delta:0;
    if(Math.abs(state.reverse)<60)return;
    state.delta=state.reverse;state.reverse=0;
    // The reversed stroke owns its own velocity profile. Keeping the preceding
    // stroke's decayed tail would classify this stroke's acceleration as another one.
    state.peak=magnitude;state.tail=false;
   }else state.delta+=delta;
   if(Math.abs(state.delta)>=60){state.locked=true;state.direction=Math.sign(state.delta);move(state.direction);state.delta=0}
  };
  node.addEventListener('wheel',onWheel,{passive:false,capture:true});return()=>node.removeEventListener('wheel',onWheel,true);
 },[api,move,cancel]);
 return {ref,containerRef,active,dragging,reduced,goTo,move,viewportProps:{
  // Pointer hover and pointer-induced focus must not pause automatic rotation.
  // Keyboard focus remains stationary so a focused product cannot move away.
  onPointerDownCapture:()=>setFocused(false),
  onFocusCapture:(event:FocusEvent<HTMLElement>)=>{if((event.target as HTMLElement).matches(':focus-visible')){cancel();setFocused(true)}},onBlurCapture:(event:FocusEvent<HTMLElement>)=>{if(!event.currentTarget.contains(event.relatedTarget as Node|null)){setFocused(false);restart()}},
  onKeyDown:(event:KeyboardEvent<HTMLElement>)=>{if(event.target!==event.currentTarget)return;if(event.key==='ArrowRight'){event.preventDefault();move(1)}if(event.key==='ArrowLeft'){event.preventDefault();move(-1)}},
  onDragStart:(event:DragEvent<HTMLElement>)=>event.preventDefault()
 }};
}
