'use client';
import {useEffect,useState} from 'react';
import './back-to-top.css';
export default function BackToTop({label,imageSrc,focusTargetId,threshold=64}:{label:string;imageSrc?:string;focusTargetId?:string;threshold?:number}){
 const [visible,setVisible]=useState(false);
 useEffect(()=>{let frame=0;const update=()=>{frame=0;setVisible(window.scrollY>threshold)};const schedule=()=>{if(!frame)frame=requestAnimationFrame(update)};update();window.addEventListener('scroll',schedule,{passive:true});return()=>{window.removeEventListener('scroll',schedule);cancelAnimationFrame(frame)}},[threshold]);
 const back=()=>{window.scrollTo({top:0,behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'});if(focusTargetId)document.getElementById(focusTargetId)?.focus({preventScroll:true})};
 return <button className={`ll-back-to-top${visible?' is-visible':''}${imageSrc?' has-image':''}`} type="button" aria-label={label} aria-hidden={!visible} tabIndex={visible?0:-1} onClick={back}>
  <span className="ll-back-to-top-tooltip" aria-hidden="true">{label}</span>
  {imageSrc&&<img src={imageSrc} width="56" height="56" alt=""/>}
  <span className="ll-back-to-top-arrow" aria-hidden="true"><svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="m5 15 7-7 7 7"/></svg></span>
 </button>;
}
